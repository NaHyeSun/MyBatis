package com.common;

public class Template {

    // * 주석을 지우고 sqlSession을 생성하는 공통 template 파일을 작성하세요.

}
